"""
predict.py — Inference module.

Loads a saved model and encoders, applies the same preprocessing pipeline,
and outputs fraud probability scores for new warranty claims.

Usage:
    python src/predict.py --input data/new_claims.csv --output outputs/predictions.csv
    python src/predict.py --input data/new_claims.csv --model rf   (default)
    python src/predict.py --input data/new_claims.csv --model xgb
"""

import os
import sys
import argparse
import warnings
import joblib
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import *
from preprocessing import clean_data, engineer_features, encode_categoricals

MODEL_MAP = {
    "lr":  LR_MODEL_PATH,
    "rf":  RF_MODEL_PATH,
    "xgb": XGB_MODEL_PATH,
}


def load_model_and_encoders(model_key="rf"):
    """Load the trained model and the label encoders."""
    model_path = MODEL_MAP.get(model_key)
    if not model_path or not os.path.exists(model_path):
        raise FileNotFoundError(
            f"Model file not found: {model_path}\n"
            "Please run train.py first."
        )
    model    = joblib.load(model_path)
    encoders = joblib.load(PIPELINE_PATH)
    print(f"[predict] Loaded model: {model_key.upper()} from {model_path}")
    return model, encoders


def preprocess_for_inference(df, encoders):
    """Apply the same cleaning, feature engineering, and encoding as training."""
    df = df.copy()

    # Drop index column if present
    if "Unnamed: 0" in df.columns:
        df = df.drop(columns=["Unnamed: 0"])

    # Remove target if present (inference on unlabelled data)
    has_target = TARGET_COL in df.columns
    if has_target:
        y_true = df[TARGET_COL].copy()
        df = df.drop(columns=[TARGET_COL])
    else:
        y_true = None

    # Apply same pipeline
    df = clean_data(df)
    df = engineer_features(df)
    df, _ = encode_categoricals(df, encoders=encoders, fit=False)

    return df, y_true


def predict(input_path, output_path, model_key="rf", threshold=FRAUD_THRESHOLD):
    """
    Load new data, preprocess, predict, and save results.
    Output CSV includes all original columns plus:
        fraud_probability  — model's predicted probability of fraud
        fraud_predicted    — 1 if probability >= threshold, else 0
        risk_label         — "High" / "Medium" / "Low"
    """
    # Load data
    df_raw = pd.read_csv(input_path)
    print(f"[predict] Loaded {len(df_raw)} rows from {input_path}")

    # Load model + encoders
    model, encoders = load_model_and_encoders(model_key)

    # Preprocess
    df_proc, y_true = preprocess_for_inference(df_raw, encoders)

    # Align feature columns to what the model was trained on
    expected_features = model.feature_names_in_ if hasattr(model, "feature_names_in_") else None
    if expected_features is not None:
        for col in expected_features:
            if col not in df_proc.columns:
                df_proc[col] = 0
        df_proc = df_proc[expected_features]

    # Predict
    proba = model.predict_proba(df_proc)[:, 1]
    pred  = (proba >= threshold).astype(int)

    # Risk label
    def risk_label(p):
        if p >= 0.7: return "High"
        if p >= 0.4: return "Medium"
        return "Low"

    # Assemble output
    out = df_raw.copy()
    out["fraud_probability"] = np.round(proba, 4)
    out["fraud_predicted"]   = pred
    out["risk_label"]        = [risk_label(p) for p in proba]

    if y_true is not None:
        out["actual_fraud"] = y_true.values
        from sklearn.metrics import classification_report, roc_auc_score
        print(f"\n[predict] Evaluation (ground truth available):")
        print(classification_report(y_true, pred, target_names=["Genuine", "Fraud"]))
        print(f"AUC-ROC: {roc_auc_score(y_true, proba):.4f}")

    # Summary
    n_flagged = pred.sum()
    print(f"\n[predict] Flagged {n_flagged} / {len(out)} claims as fraud "
          f"({100*n_flagged/len(out):.2f}%)")
    print(f"[predict] Risk breakdown:\n{out['risk_label'].value_counts().to_string()}")

    # Save
    os.makedirs(os.path.dirname(output_path) if os.path.dirname(output_path) else ".", exist_ok=True)
    out.to_csv(output_path, index=False)
    print(f"\n[predict] Predictions saved → {output_path}")
    return out


# ─── Run standalone ───────────────────────────────────────────────────────────

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Warranty Fraud Prediction")
    parser.add_argument("--input",  type=str, default=RAW_DATA_PATH,
                        help="Path to input CSV")
    parser.add_argument("--output", type=str,
                        default=os.path.join(OUTPUT_DIR, "predictions.csv"),
                        help="Path to save predictions CSV")
    parser.add_argument("--model",  type=str, default="rf",
                        choices=["lr", "rf", "xgb"],
                        help="Which model to use for inference")
    parser.add_argument("--threshold", type=float, default=FRAUD_THRESHOLD,
                        help="Probability threshold for fraud flag")
    args = parser.parse_args()

    predict(args.input, args.output, args.model, args.threshold)
