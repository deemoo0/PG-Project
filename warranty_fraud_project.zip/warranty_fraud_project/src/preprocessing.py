"""
preprocessing.py — Data loading, cleaning, feature engineering,
encoding, and train/test splitting for Warranty Fraud Detection.

Oversampling: manual random oversampling (replaces SMOTE).
Install imbalanced-learn for SMOTE: pip install imbalanced-learn
"""

import os, sys, warnings, joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.utils import resample

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import *


def load_data(path=RAW_DATA_PATH):
    df = pd.read_csv(path)
    if "Unnamed: 0" in df.columns:
        df = df.drop(columns=["Unnamed: 0"])
    print(f"[load]  Shape: {df.shape}  |  Fraud: {df[TARGET_COL].sum()} ({df[TARGET_COL].mean()*100:.2f}%)")
    return df


def data_quality_report(df):
    print("\n=== DATA QUALITY REPORT ===")
    missing = df.isnull().sum()
    missing = missing[missing > 0]
    print("Missing values:\n" + (missing.to_string() if len(missing) else "  None"))
    cols = [c for c in ["Claim_Value", "Product_Age", "Call_details"] if c in df.columns]
    print(f"\nNumerical summary:\n{df[cols].describe().round(2).to_string()}")
    print("\nFraud rate by key columns:")
    for col in ["Region", "Product_type", "Consumer_profile", "Area"]:
        if col in df.columns:
            fr = df.groupby(col)[TARGET_COL].mean().sort_values(ascending=False)
            print(f"  {col}: " + "  |  ".join([f"{k}={v:.3f}" for k, v in fr.items()]))


def clean_data(df):
    df = df.copy()
    if "Claim_Value" in df.columns:
        med = df["Claim_Value"].median()
        n = df["Claim_Value"].isnull().sum()
        df["Claim_Value"] = df["Claim_Value"].fillna(med)
        if n: print(f"[clean] Imputed {n} Claim_Value nulls with median={med:.0f}")
    if "Purpose" in df.columns:
        df["Purpose"] = df["Purpose"].str.strip().str.capitalize()
    # Deduplication disabled — duplicate rows are genuine claims


    return df


def engineer_features(df):
    df = df.copy()
    issue_cols = [c for c in ["AC_1001_Issue","AC_1002_Issue","AC_1003_Issue",
                               "TV_2001_Issue","TV_2002_Issue","TV_2003_Issue"] if c in df.columns]
    df["Issue_count"]    = df[issue_cols].sum(axis=1)
    df["Claim_per_age"]  = df["Claim_Value"] / (df["Product_Age"] + 1)
    df["Is_new_product"] = (df["Product_Age"] <= 30).astype(int)
    df["Is_high_value"]  = (df["Claim_Value"] > df["Claim_Value"].quantile(0.75)).astype(int)
    print("[feat]  Engineered 4 new features: Issue_count, Claim_per_age, Is_new_product, Is_high_value")
    return df


def encode_categoricals(df, encoders=None, fit=True):
    df = df.copy()
    if fit: encoders = {}
    for col in CATEGORICAL_COLS:
        if col not in df.columns: continue
        if fit:
            le = LabelEncoder()
            df[col] = le.fit_transform(df[col].astype(str))
            encoders[col] = le
        else:
            le = encoders[col]
            known = set(le.classes_)
            df[col] = df[col].astype(str).apply(lambda x: x if x in known else le.classes_[0])
            df[col] = le.transform(df[col])
    print(f"[enc]   Label-encoded {len(CATEGORICAL_COLS)} categorical columns")
    return df, encoders


def oversample_minority(X_train, y_train):
    df = pd.concat([X_train, y_train], axis=1)
    maj = df[df[TARGET_COL] == 0]
    mn  = df[df[TARGET_COL] == 1]
    mn_up = resample(mn, replace=True, n_samples=len(maj), random_state=RANDOM_STATE)
    df_bal = pd.concat([maj, mn_up]).sample(frac=1, random_state=RANDOM_STATE).reset_index(drop=True)
    X_bal = df_bal.drop(columns=[TARGET_COL])
    y_bal = df_bal[TARGET_COL]
    print(f"[over]  After oversampling — Train: {X_bal.shape}  Fraud rate: {y_bal.mean():.3f}")
    return X_bal, y_bal


def split_data(df):
    feature_cols = [c for c in df.columns if c != TARGET_COL]
    X, y = df[feature_cols], df[TARGET_COL]
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE, stratify=y)
    print(f"[split] Train: {X_train.shape}  Test: {X_test.shape}  "
          f"| Train fraud: {y_train.mean():.4f}  Test fraud: {y_test.mean():.4f}")
    return X_train, X_test, y_train, y_test, feature_cols


def run_preprocessing(apply_oversampling=True, save=True):
    os.makedirs(DATA_DIR, exist_ok=True)
    os.makedirs(MODEL_DIR, exist_ok=True)
    df = load_data()
    data_quality_report(df)
    df = clean_data(df)
    df = engineer_features(df)
    df, encoders = encode_categoricals(df, fit=True)
    X_train, X_test, y_train, y_test, feature_cols = split_data(df)
    if apply_oversampling:
        X_train, y_train = oversample_minority(X_train, y_train)
    if save:
        joblib.dump(encoders, PIPELINE_PATH)
        print(f"[save]  Encoders saved → {PIPELINE_PATH}")
    return X_train, X_test, y_train, y_test, feature_cols, encoders


if __name__ == "__main__":
    X_train, X_test, y_train, y_test, features, encoders = run_preprocessing()
    print(f"\nDone. {len(features)} features.")
