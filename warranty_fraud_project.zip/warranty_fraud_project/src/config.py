"""
config.py — Central configuration for the Warranty Fraud Detection project.
"""
import os

# ─── Paths ────────────────────────────────────────────────────────────────────
BASE_DIR   = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_DIR   = os.path.join(BASE_DIR, "data")
MODEL_DIR  = os.path.join(BASE_DIR, "models")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
REPORT_DIR = os.path.join(BASE_DIR, "reports")

RAW_DATA_PATH       = os.path.join(DATA_DIR, "train.csv")
PIPELINE_PATH       = os.path.join(MODEL_DIR, "preprocessing_pipeline.pkl")
LR_MODEL_PATH       = os.path.join(MODEL_DIR, "logistic_regression.pkl")
RF_MODEL_PATH       = os.path.join(MODEL_DIR, "random_forest.pkl")
XGB_MODEL_PATH      = os.path.join(MODEL_DIR, "gradient_boosting.pkl")

# ─── Dataset ──────────────────────────────────────────────────────────────────
TARGET_COL = "Fraud"

CATEGORICAL_COLS = [
    "Region", "State", "Area", "City",
    "Consumer_profile", "Product_category",
    "Product_type", "Purchased_from", "Purpose"
]

NUMERICAL_COLS = [
    "Claim_Value", "Service_Centre", "Product_Age", "Call_details",
    "AC_1001_Issue", "AC_1002_Issue", "AC_1003_Issue",
    "TV_2001_Issue", "TV_2002_Issue", "TV_2003_Issue"
]

# ─── Split / CV ───────────────────────────────────────────────────────────────
TEST_SIZE    = 0.20
RANDOM_STATE = 42
CV_FOLDS     = 5

# ─── Model hyperparameters ────────────────────────────────────────────────────
LR_PARAMS = dict(max_iter=1000, class_weight="balanced",
                 random_state=RANDOM_STATE, solver="lbfgs")

RF_PARAMS = dict(n_estimators=200, max_depth=None, min_samples_split=4,
                 min_samples_leaf=2, class_weight="balanced",
                 random_state=RANDOM_STATE, n_jobs=-1)

XGB_PARAMS = dict(n_estimators=200, max_depth=5, learning_rate=0.1,
                  subsample=0.8, max_features="sqrt", random_state=RANDOM_STATE)

# ─── Grids for RandomizedSearchCV ─────────────────────────────────────────────
RF_GRID = {
    "n_estimators": [100, 200, 300],
    "max_depth": [None, 10, 20],
    "min_samples_leaf": [1, 2, 4],
}
XGB_GRID = {
    "n_estimators": [100, 200],
    "max_depth": [3, 5, 7],
    "learning_rate": [0.05, 0.1, 0.2],
}

# ─── Evaluation ───────────────────────────────────────────────────────────────
FRAUD_THRESHOLD = 0.5
PLOT_DPI        = 150
FIGURE_SIZE     = (10, 6)
