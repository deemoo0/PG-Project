"""
evaluate.py — Comprehensive model evaluation and visualisation.

Generates:
  - EDA plots (class distribution, fraud by region, claim value, correlation, segments)
  - Confusion matrices (per model)
  - ROC curve comparison
  - Precision-Recall curve comparison
  - Feature importance bar chart (Random Forest)
  - Model comparison CSV
"""

import os, sys, warnings
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import (
    confusion_matrix, roc_auc_score, roc_curve,
    precision_recall_curve, average_precision_score,
    f1_score, precision_score, recall_score, accuracy_score
)

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import *

os.makedirs(OUTPUT_DIR, exist_ok=True)

plt.rcParams.update({
    "figure.dpi": PLOT_DPI,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "axes.grid": True,
    "grid.alpha": 0.25,
    "font.size": 11,
})

COLORS = {"lr": "#888780", "rf": "#185FA5", "xgb": "#854F0B"}
LABELS = {"lr": "Logistic Regression", "rf": "Random Forest", "xgb": "Gradient Boosting"}


# ─── EDA plots ────────────────────────────────────────────────────────────────

def plot_eda(df):
    """5 EDA charts saved to outputs/."""

    # 1. Class distribution
    fig, ax = plt.subplots(figsize=(5, 4))
    counts = df["Fraud"].value_counts()
    bars = ax.bar(["Genuine (0)", "Fraud (1)"], counts.values,
                  color=["#185FA5", "#993C1D"], alpha=0.85, width=0.5, edgecolor="white")
    for bar, v in zip(bars, counts.values):
        ax.text(bar.get_x() + bar.get_width()/2, v + 40, f"{v}\n({v/len(df)*100:.1f}%)",
                ha="center", fontsize=10)
    ax.set_ylabel("Count"); ax.set_title("Class Distribution", fontweight="bold")
    ax.set_ylim(0, counts.max() * 1.15)
    plt.tight_layout()
    p1 = os.path.join(OUTPUT_DIR, "eda_01_class_distribution.png")
    fig.savefig(p1, bbox_inches="tight"); plt.close(fig)

    # 2. Fraud rate by Region
    region_fr = df.groupby("Region")["Fraud"].mean().sort_values(ascending=False)
    fig, ax = plt.subplots(figsize=(9, 4))
    bars = ax.bar(region_fr.index, region_fr.values * 100,
                  color="#185FA5", alpha=0.8, edgecolor="white")
    ax.axhline(df["Fraud"].mean() * 100, color="#993C1D", linestyle="--", lw=1.5,
               label=f"Overall avg ({df['Fraud'].mean()*100:.1f}%)")
    for bar, v in zip(bars, region_fr.values * 100):
        ax.text(bar.get_x() + bar.get_width()/2, v + 0.2, f"{v:.1f}%",
                ha="center", fontsize=9)
    ax.set_ylabel("Fraud Rate (%)"); ax.set_title("Fraud Rate by Region", fontweight="bold")
    ax.legend(); plt.xticks(rotation=20, ha="right"); plt.tight_layout()
    p2 = os.path.join(OUTPUT_DIR, "eda_02_fraud_by_region.png")
    fig.savefig(p2, bbox_inches="tight"); plt.close(fig)

    # 3. Claim value distribution by class
    fig, ax = plt.subplots(figsize=(8, 4))
    for label, color, name in [(0, "#185FA5", "Genuine"), (1, "#993C1D", "Fraud")]:
        vals = df[df["Fraud"] == label]["Claim_Value"].dropna()
        ax.hist(vals, bins=40, alpha=0.6, color=color, label=f"{name} (n={len(vals)})",
                edgecolor="white")
    ax.set_xlabel("Claim Value (₹)"); ax.set_ylabel("Count")
    ax.set_title("Claim Value Distribution by Class", fontweight="bold")
    ax.legend(); plt.tight_layout()
    p3 = os.path.join(OUTPUT_DIR, "eda_03_claim_value_dist.png")
    fig.savefig(p3, bbox_inches="tight"); plt.close(fig)

    # 4. Correlation heatmap
    num_cols = [c for c in ["Claim_Value","Product_Age","Call_details",
                "AC_1001_Issue","AC_1002_Issue","AC_1003_Issue",
                "TV_2001_Issue","TV_2002_Issue","TV_2003_Issue",
                "Service_Centre","Fraud"] if c in df.columns]
    fig, ax = plt.subplots(figsize=(10, 7))
    corr = df[num_cols].dropna().corr()
    mask = np.triu(np.ones_like(corr, dtype=bool))
    sns.heatmap(corr, mask=mask, annot=True, fmt=".2f", cmap="coolwarm",
                center=0, linewidths=0.4, ax=ax, annot_kws={"size": 8})
    ax.set_title("Feature Correlation Heatmap", fontweight="bold")
    plt.tight_layout()
    p4 = os.path.join(OUTPUT_DIR, "eda_04_correlation_heatmap.png")
    fig.savefig(p4, bbox_inches="tight"); plt.close(fig)

    # 5. Fraud rate by multiple segments
    fig, axes = plt.subplots(2, 2, figsize=(11, 7))
    segments = ["Product_type", "Consumer_profile", "Area", "Purpose"]
    for ax, col in zip(axes.flat, segments):
        if col not in df.columns: continue
        fr = df.groupby(col)["Fraud"].mean().sort_values(ascending=False) * 100
        bars = ax.bar(fr.index, fr.values, color="#185FA5", alpha=0.8, edgecolor="white")
        ax.axhline(df["Fraud"].mean() * 100, color="#993C1D", linestyle="--", lw=1.2)
        for bar, v in zip(bars, fr.values):
            ax.text(bar.get_x() + bar.get_width()/2, v + 0.1, f"{v:.1f}%",
                    ha="center", fontsize=8)
        ax.set_title(f"Fraud Rate by {col}", fontweight="bold", fontsize=10)
        ax.set_ylabel("Fraud Rate (%)"); ax.tick_params(axis="x", rotation=15)
    plt.suptitle("Fraud Rate by Key Segments", fontsize=13, fontweight="bold", y=1.01)
    plt.tight_layout()
    p5 = os.path.join(OUTPUT_DIR, "eda_05_fraud_by_segments.png")
    fig.savefig(p5, bbox_inches="tight"); plt.close(fig)

    print(f"[eda]   Saved 5 EDA plots to {OUTPUT_DIR}/")
    return [p1, p2, p3, p4, p5]


# ─── Confusion matrix ─────────────────────────────────────────────────────────

def plot_confusion_matrix(y_test, y_pred, model_name, key):
    cm = confusion_matrix(y_test, y_pred)
    fig, ax = plt.subplots(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Genuine", "Fraud"],
                yticklabels=["Genuine", "Fraud"],
                linewidths=0.5, ax=ax, annot_kws={"size": 14})
    ax.set_xlabel("Predicted", fontsize=12); ax.set_ylabel("Actual", fontsize=12)
    ax.set_title(f"Confusion Matrix — {model_name}", fontweight="bold")
    tn, fp, fn, tp = cm.ravel()
    ax.set_xlabel(f"Predicted\n\nTP={tp}  FP={fp}  FN={fn}  TN={tn}", fontsize=10)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, f"confusion_matrix_{key}.png")
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"[eval]  Confusion matrix → {path}")
    return path


# ─── ROC curves ───────────────────────────────────────────────────────────────

def plot_roc_curves(y_test, probas_dict):
    fig, ax = plt.subplots(figsize=FIGURE_SIZE)
    for key, y_proba in probas_dict.items():
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        auc = roc_auc_score(y_test, y_proba)
        ax.plot(fpr, tpr, lw=2.5, color=COLORS[key],
                label=f"{LABELS[key]}  (AUC = {auc:.4f})")
    ax.plot([0,1],[0,1], "k--", lw=1, alpha=0.4, label="Random classifier")
    ax.fill_between([0,1],[0,1], alpha=0.03, color="gray")
    ax.set_xlabel("False Positive Rate", fontsize=12)
    ax.set_ylabel("True Positive Rate", fontsize=12)
    ax.set_title("ROC Curve Comparison", fontsize=14, fontweight="bold")
    ax.legend(loc="lower right", fontsize=10)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "roc_curves_comparison.png")
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"[eval]  ROC curves → {path}")
    return path


# ─── Precision-Recall curves ──────────────────────────────────────────────────

def plot_pr_curves(y_test, probas_dict):
    fig, ax = plt.subplots(figsize=FIGURE_SIZE)
    for key, y_proba in probas_dict.items():
        prec, rec, _ = precision_recall_curve(y_test, y_proba)
        ap = average_precision_score(y_test, y_proba)
        ax.plot(rec, prec, lw=2.5, color=COLORS[key],
                label=f"{LABELS[key]}  (AP = {ap:.4f})")
    baseline = y_test.mean()
    ax.axhline(baseline, color="gray", linestyle="--", lw=1,
               label=f"No-skill baseline ({baseline:.3f})")
    ax.set_xlabel("Recall", fontsize=12); ax.set_ylabel("Precision", fontsize=12)
    ax.set_title("Precision-Recall Curve Comparison", fontsize=14, fontweight="bold")
    ax.legend(loc="upper right", fontsize=10)
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "pr_curves_comparison.png")
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"[eval]  PR curves → {path}")
    return path


# ─── Feature importance ───────────────────────────────────────────────────────

def plot_feature_importance(rf_model, feature_names, top_n=15):
    fi = pd.Series(rf_model.feature_importances_, index=feature_names)
    fi = fi.sort_values(ascending=True).tail(top_n)
    fig, ax = plt.subplots(figsize=(8, 6))
    bars = ax.barh(fi.index, fi.values, color="#185FA5", alpha=0.82, edgecolor="white")
    for bar, val in zip(bars, fi.values):
        ax.text(val + 0.0005, bar.get_y() + bar.get_height()/2,
                f"{val:.4f}", va="center", fontsize=9)
    ax.set_xlabel("Importance Score", fontsize=12)
    ax.set_title(f"Random Forest — Top {top_n} Feature Importances",
                 fontsize=13, fontweight="bold")
    plt.tight_layout()
    path = os.path.join(OUTPUT_DIR, "feature_importance_rf.png")
    fig.savefig(path, bbox_inches="tight"); plt.close(fig)
    print(f"[eval]  Feature importance → {path}")
    return path


# ─── Model comparison table ───────────────────────────────────────────────────

def model_comparison_table(y_test, results_dict):
    rows = []
    for key, (model, y_pred, y_proba) in results_dict.items():
        rows.append({
            "Model":     LABELS[key],
            "Accuracy":  round(accuracy_score(y_test, y_pred), 4),
            "Precision": round(precision_score(y_test, y_pred, zero_division=0), 4),
            "Recall":    round(recall_score(y_test, y_pred, zero_division=0), 4),
            "F1-Score":  round(f1_score(y_test, y_pred, zero_division=0), 4),
            "AUC-ROC":   round(roc_auc_score(y_test, y_proba), 4),
            "AUC-PR":    round(average_precision_score(y_test, y_proba), 4),
        })
    df = pd.DataFrame(rows)
    path = os.path.join(OUTPUT_DIR, "model_comparison.csv")
    df.to_csv(path, index=False)
    print(f"\n[eval]  Model Comparison:\n{df.to_string(index=False)}")
    print(f"[eval]  Saved → {path}")
    return df


# ─── Master function ──────────────────────────────────────────────────────────

def run_evaluation(y_test, results_dict, X_test, feature_names, df_raw=None):
    if df_raw is not None:
        plot_eda(df_raw)

    for key, (model, y_pred, y_proba) in results_dict.items():
        plot_confusion_matrix(y_test, y_pred, LABELS[key], key)

    probas = {k: v[2] for k, v in results_dict.items()}
    plot_roc_curves(y_test, probas)
    plot_pr_curves(y_test, probas)
    plot_feature_importance(results_dict["rf"][0], feature_names)

    comparison = model_comparison_table(y_test, results_dict)
    print("\n[eval]  All evaluation plots generated.")
    return comparison


if __name__ == "__main__":
    import joblib
    from preprocessing import run_preprocessing, load_data
    X_train, X_test, y_train, y_test, features, encoders = run_preprocessing(save=False)
    X_train = pd.DataFrame(X_train, columns=features)
    X_test  = pd.DataFrame(X_test,  columns=features)
    lr  = joblib.load(LR_MODEL_PATH)
    rf  = joblib.load(RF_MODEL_PATH)
    xgb = joblib.load(XGB_MODEL_PATH)
    results = {
        "lr":  (lr,  lr.predict(X_test),  lr.predict_proba(X_test)[:,1]),
        "rf":  (rf,  rf.predict(X_test),  rf.predict_proba(X_test)[:,1]),
        "xgb": (xgb, xgb.predict(X_test), xgb.predict_proba(X_test)[:,1]),
    }
    run_evaluation(y_test, results, X_test, features, load_data())
