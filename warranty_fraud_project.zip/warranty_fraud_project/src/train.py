"""
train.py — Model training and cross-validation.

Models:
  1. Logistic Regression      (baseline)
  2. Random Forest            (primary model)
  3. Gradient Boosting        (XGBoost equivalent, built into sklearn)

Replace GradientBoostingClassifier with XGBClassifier if you have xgboost installed:
    pip install xgboost
    from xgboost import XGBClassifier
"""

import os, sys, warnings, joblib
import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import StratifiedKFold, cross_validate, RandomizedSearchCV
from sklearn.metrics import (classification_report, roc_auc_score,
                             average_precision_score)

warnings.filterwarnings("ignore")
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import *

os.makedirs(MODEL_DIR, exist_ok=True)


# ─── Cross-validation helper ──────────────────────────────────────────────────

def cross_validate_model(model, X, y, label="Model"):
    cv = StratifiedKFold(n_splits=CV_FOLDS, shuffle=True, random_state=RANDOM_STATE)
    scoring = ["roc_auc", "f1", "precision", "recall"]
    r = cross_validate(model, X, y, cv=cv, scoring=scoring, n_jobs=-1)
    print(f"\n[CV] {label} — {CV_FOLDS}-fold Stratified CV")
    for m in scoring:
        vals = r[f"test_{m}"]
        print(f"     {m:12s}: {vals.mean():.4f} ± {vals.std():.4f}")
    return r


# ─── 1. Logistic Regression ───────────────────────────────────────────────────

def train_logistic_regression(X_train, y_train, X_test, y_test):
    print("\n" + "="*60)
    print("  1. LOGISTIC REGRESSION  (Baseline)")
    print("="*60)
    model = LogisticRegression(**LR_PARAMS)
    model.fit(X_train, y_train)
    cross_validate_model(model, X_train, y_train, "Logistic Regression")
    y_pred  = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]
    print(f"\n  Test AUC-ROC : {roc_auc_score(y_test, y_proba):.4f}")
    print(f"  Test AUC-PR  : {average_precision_score(y_test, y_proba):.4f}")
    print(f"\n{classification_report(y_test, y_pred, target_names=['Genuine','Fraud'])}")
    joblib.dump(model, LR_MODEL_PATH)
    print(f"  Saved → {LR_MODEL_PATH}")
    return model, y_pred, y_proba


# ─── 2. Random Forest ─────────────────────────────────────────────────────────

def train_random_forest(X_train, y_train, X_test, y_test, tune=False):
    print("\n" + "="*60)
    print("  2. RANDOM FOREST")
    print("="*60)
    if tune:
        print("  Running RandomizedSearchCV ...")
        base = RandomForestClassifier(class_weight="balanced",
                                      random_state=RANDOM_STATE, n_jobs=-1)
        search = RandomizedSearchCV(base, RF_GRID, n_iter=8, cv=3,
                                    scoring="roc_auc", n_jobs=-1,
                                    random_state=RANDOM_STATE, verbose=1)
        search.fit(X_train, y_train)
        model = search.best_estimator_
        print(f"  Best params: {search.best_params_}")
    else:
        model = RandomForestClassifier(**RF_PARAMS)
        model.fit(X_train, y_train)

    cross_validate_model(model, X_train, y_train, "Random Forest")
    y_pred  = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]
    print(f"\n  Test AUC-ROC : {roc_auc_score(y_test, y_proba):.4f}")
    print(f"  Test AUC-PR  : {average_precision_score(y_test, y_proba):.4f}")
    print(f"\n{classification_report(y_test, y_pred, target_names=['Genuine','Fraud'])}")

    fi = pd.Series(model.feature_importances_,
                   index=X_train.columns).sort_values(ascending=False)
    print("  Top 10 Features:")
    for feat, score in fi.head(10).items():
        print(f"    {feat:25s}: {score:.4f}")

    joblib.dump(model, RF_MODEL_PATH)
    print(f"\n  Saved → {RF_MODEL_PATH}")
    return model, y_pred, y_proba


# ─── 3. Gradient Boosting (XGBoost equivalent) ────────────────────────────────

def train_gradient_boosting(X_train, y_train, X_test, y_test, tune=False):
    print("\n" + "="*60)
    print("  3. GRADIENT BOOSTING  (XGBoost equivalent)")
    print("="*60)
    if tune:
        print("  Running RandomizedSearchCV ...")
        base = GradientBoostingClassifier(random_state=RANDOM_STATE)
        search = RandomizedSearchCV(base, XGB_GRID, n_iter=8, cv=3,
                                    scoring="roc_auc", n_jobs=-1,
                                    random_state=RANDOM_STATE, verbose=1)
        search.fit(X_train, y_train)
        model = search.best_estimator_
        print(f"  Best params: {search.best_params_}")
    else:
        model = GradientBoostingClassifier(**XGB_PARAMS)
        model.fit(X_train, y_train)

    cross_validate_model(model, X_train, y_train, "Gradient Boosting")
    y_pred  = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]
    print(f"\n  Test AUC-ROC : {roc_auc_score(y_test, y_proba):.4f}")
    print(f"  Test AUC-PR  : {average_precision_score(y_test, y_proba):.4f}")
    print(f"\n{classification_report(y_test, y_pred, target_names=['Genuine','Fraud'])}")

    joblib.dump(model, XGB_MODEL_PATH)
    print(f"\n  Saved → {XGB_MODEL_PATH}")
    return model, y_pred, y_proba


# ─── Master training function ─────────────────────────────────────────────────

def run_training(X_train, X_test, y_train, y_test, tune=False):
    results = {}
    results["lr"]  = train_logistic_regression(X_train, y_train, X_test, y_test)
    results["rf"]  = train_random_forest(X_train, y_train, X_test, y_test, tune=tune)
    results["xgb"] = train_gradient_boosting(X_train, y_train, X_test, y_test, tune=tune)
    return results


if __name__ == "__main__":
    from preprocessing import run_preprocessing
    X_train, X_test, y_train, y_test, features, encoders = run_preprocessing()
    X_train = pd.DataFrame(X_train, columns=features)
    X_test  = pd.DataFrame(X_test,  columns=features)
    run_training(X_train, X_test, y_train, y_test, tune=False)
    print("\nAll models trained and saved.")
