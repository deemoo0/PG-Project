"""
full_analysis.py  —  End-to-end pipeline
M.Sc. Final Year Project: Predictive Analytics for Warranty Claim Fraud Detection

Run:  python notebooks/full_analysis.py
"""

import os, sys, warnings
import numpy as np
import pandas as pd

warnings.filterwarnings("ignore")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))

from config import *
from preprocessing import run_preprocessing, load_data
from train import run_training
from evaluate import run_evaluation

def banner(text):
    width = 65
    print("\n" + "═" * width)
    print(f"  {text}")
    print("═" * width)

def main():
    os.makedirs(OUTPUT_DIR, exist_ok=True)
    os.makedirs(MODEL_DIR,  exist_ok=True)

    # ── Phase 1: Raw data overview ────────────────────────────────────────────
    banner("PHASE 1 — Data Loading & Exploratory Analysis")
    df_raw = load_data()
    print(f"\n  Rows            : {len(df_raw):,}")
    print(f"  Columns         : {df_raw.shape[1]}")
    print(f"  Fraud cases     : {df_raw['Fraud'].sum():,}  ({df_raw['Fraud'].mean()*100:.2f}%)")
    print(f"  Genuine cases   : {(df_raw['Fraud']==0).sum():,}")
    print(f"\n  Claim Value stats:")
    print(f"    Overall avg   : ₹{df_raw['Claim_Value'].mean():,.0f}")
    print(f"    Genuine avg   : ₹{df_raw[df_raw['Fraud']==0]['Claim_Value'].mean():,.0f}")
    print(f"    Fraud avg     : ₹{df_raw[df_raw['Fraud']==1]['Claim_Value'].mean():,.0f}")
    print(f"\n  Fraud rate by Region:")
    rg = df_raw.groupby("Region")["Fraud"].mean().sort_values(ascending=False)
    for r, v in rg.items():
        bar = "█" * int(v * 100)
        print(f"    {r:15s}: {v*100:5.1f}%  {bar}")

    # ── Phase 2: Preprocessing ────────────────────────────────────────────────
    banner("PHASE 2 — Preprocessing & Feature Engineering")
    X_train, X_test, y_train, y_test, features, encoders = run_preprocessing(
        apply_oversampling=True, save=True
    )
    X_train = pd.DataFrame(X_train, columns=features)
    X_test  = pd.DataFrame(X_test,  columns=features)

    print(f"\n  Final features ({len(features)}):")
    for i, f in enumerate(features, 1):
        print(f"    {i:2d}. {f}")

    # ── Phase 3: Model Training ───────────────────────────────────────────────
    banner("PHASE 3 — Model Training (3 algorithms)")
    results = run_training(X_train, X_test, y_train, y_test, tune=False)

    # ── Phase 4: Evaluation ───────────────────────────────────────────────────
    banner("PHASE 4 — Evaluation & Visualisation")
    comparison = run_evaluation(
        y_test=y_test,
        results_dict=results,
        X_test=X_test,
        feature_names=features,
        df_raw=df_raw
    )

    # ── Phase 5: Predictions on full test set ─────────────────────────────────
    banner("PHASE 5 — Predictions with Best Model (Random Forest)")
    rf_model = results["rf"][0]
    proba = rf_model.predict_proba(X_test)[:, 1]
    pred  = (proba >= FRAUD_THRESHOLD).astype(int)

    def risk(p):
        return "High" if p >= 0.7 else "Medium" if p >= 0.4 else "Low"

    out = X_test.copy()
    out["actual_fraud"]      = y_test.values
    out["fraud_probability"] = np.round(proba, 4)
    out["fraud_predicted"]   = pred
    out["risk_label"]        = [risk(p) for p in proba]
    out.to_csv(os.path.join(OUTPUT_DIR, "predictions.csv"), index=False)

    print(f"\n  Flagged {pred.sum()} / {len(pred)} claims as fraud")
    print(f"  Risk breakdown:\n{out['risk_label'].value_counts().to_string()}")
    print(f"\n  Predictions saved → {os.path.join(OUTPUT_DIR, 'predictions.csv')}")

    # ── Phase 6: Summary ──────────────────────────────────────────────────────
    banner("PHASE 6 — FINAL RESULTS SUMMARY")
    print(f"\n{comparison.to_string(index=False)}")
    best_row = comparison.loc[comparison["AUC-ROC"].idxmax()]
    print(f"\n  Best model  : {best_row['Model']}")
    print(f"  AUC-ROC     : {best_row['AUC-ROC']}")
    print(f"  Recall      : {best_row['Recall']}")
    print(f"  F1-Score    : {best_row['F1-Score']}")
    print(f"\n  Outputs → {OUTPUT_DIR}/")
    print(f"  Models  → {MODEL_DIR}/")

    banner("PIPELINE COMPLETE — Warranty Fraud Detection")


if __name__ == "__main__":
    main()
