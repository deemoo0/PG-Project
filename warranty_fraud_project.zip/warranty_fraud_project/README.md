# Warranty Claim Fraud Detection — M.Sc. Data Science Final Year Project

## Project Overview
This project builds a machine learning pipeline to detect fraudulent warranty claims
using Logistic Regression, Random Forest, and XGBoost classifiers.

## Project Structure
```
warranty_fraud_project/
├── data/                   # Raw dataset
│   └── train.csv
├── src/                    # Source modules
│   ├── config.py           # All configuration constants
│   ├── preprocessing.py    # Data cleaning & feature engineering
│   ├── train.py            # Model training & hyperparameter tuning
│   ├── evaluate.py         # Evaluation metrics & plots
│   └── predict.py          # Inference on new data
├── notebooks/
│   └── full_analysis.py    # End-to-end notebook-style script
├── models/                 # Saved model files (.pkl)
├── outputs/                # Plots, reports, predictions
├── requirements.txt
└── README.md
```

## How to Run

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run full pipeline (recommended)
```bash
python notebooks/full_analysis.py
```

### 3. Run individual modules
```bash
# Preprocessing only
python src/preprocessing.py

# Training only (after preprocessing)
python src/train.py

# Evaluation only (after training)
python src/evaluate.py

# Predict on new data
python src/predict.py --input data/new_claims.csv --output outputs/predictions.csv
```

## Results Summary
| Model              | Accuracy | Precision | Recall | F1    | AUC-ROC |
|--------------------|----------|-----------|--------|-------|---------|
| Logistic Regression| 92.0%    | —         | 0.0%   | 0.00  | 0.821   |
| Random Forest      | 98.1%    | 86.0%     | 91.0%  | 0.88  | 0.997   |
| XGBoost            | 97.8%    | 84.0%     | 89.0%  | 0.86  | 0.995   |

## Dataset
- 8,341 warranty claims (AC & TV products)
- 21 features: Region, State, Area, City, Consumer_profile, Product_type, Claim_Value, etc.
- Target: Fraud (1 = fraud, 0 = genuine)
- Class imbalance: 7.98% fraud rate — handled with SMOTE

## Key Findings
- Random Forest achieves AUC of 0.997 on test set
- Top fraud predictors: Claim_Value, Product_Age, Purchased_from, City, Call_details
- East region has 17.9% fraud rate vs 7.98% average
- Fraudulent claims average 50% higher value than genuine claims
